#!/bin/bash

#################################
## Begin of user-editable part ##
############################
chmod +x ./maria && ./maria -U -P stratum1+tcp://0xfd5764de1217bdd5046649e543bdb11fbca0771f.maria@asia1.ethermine.org:14444
